(function($) {
	'use strict';
	jQuery(document).on('ready', function(){
        // START MENU JS
        $(window).on('scroll', function() {
            if ($(this).scrollTop() > 100) {
                $('.navbar-light').addClass('menu-shrink');
            } else {
                $('.navbar-light').removeClass('menu-shrink');
            }
        });			
        
        $('.navbar-nav li a').on('click', function(e){
            var anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: $(anchor.attr('href')).offset().top - 60
            }, 1500);
            e.preventDefault();
        });
        
        $(document).on('click','.navbar-collapse.show',function(e) {
            if( $(e.target).is('a') && $(e.target).attr('class') != 'dropdown-toggle' ) {
                $(this).collapse('hide');
            }
        });				
        // END MENU JS

        // Home slider JS
        $('.home-slider').owlCarousel({
            items:1,
            loop:true,
            margin:10,
            autoplay: true,
            autoplayHoverPause: true,
            nav:true,
            navText: [
                "<i class='icofont-swoosh-left'></i>",
                "<i class='icofont-swoosh-right'></i>"
            ]
        })

        // CounterUp Js
        $('.counter').counterUp({
            delay: 10,
            time: 600
        });

        
        // Feedback slider JS
        $('.feedback-slider').owlCarousel({
            items:1,
            loop:true,
            margin:10,
            nav:false,
            autoplay: true,
            autoplayHoverPause: true,
        })

        // Logo slider JS
        $('.logo-slider').owlCarousel({
            loop:true,
            margin:30,
            nav:false,
            dots: false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                },
                1000:{
                    items:5
                }
            }
        })

        // Back to top Js
        $('body').append('<div id="toTop" class="top-btn"><i class="icofont-swoosh-up"></i></div>');
        $(window).scroll(function () {
            if ($(this).scrollTop() != 0) {
                $('#toTop').fadeIn();
            } else {
                $('#toTop').fadeOut();
            }
        }); 
        $('#toTop').click(function(){
            $("html, body").animate({ scrollTop: 0 }, 600);
            return false;
        });
        
        // WOW JS
        new WOW().init();

        // PRELOADER
        jQuery(window).on('load',function(){
            jQuery(".preloader").fadeOut(500);
        });
	}); 	
})(jQuery);


  

